from hwid_auth import authenticate
from automation import start_main_application
from updater import update_app
import sys
import config
import requests

def fetch_allowed_hwids():
    try:
        url = config.decrypt(config.ENCRYPTED_PASTEBIN_URL)
        response = requests.get(url)
        response.raise_for_status()
        return response.text.strip().split('\n')
    except requests.RequestException as e:
        print(f"Error fetching allowed HWIDs: {e}")
        return []

def main():
    if authenticate(fetch_allowed_hwids()):
        print("Authentication successful.")

        # Check for updates
        if update_app():
            print("Application updated. Please restart.")
            sys.exit(0)

        print("Starting main application...")
        start_main_application()
    else:
        print("Access denied. Exiting...")
        sys.exit(1)

if __name__ == "__main__":
    main()